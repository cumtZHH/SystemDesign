package entity;

public class categories {
	public String category_id ;
	public String categoryName;
}
