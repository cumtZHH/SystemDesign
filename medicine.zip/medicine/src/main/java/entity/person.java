package entity;

public class person {
	public String person_id;
	public String person_name;
	public String tel;
	public String pwd;
	public String role_id;
}
