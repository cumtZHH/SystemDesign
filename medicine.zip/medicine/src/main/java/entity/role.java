package entity;

public class role {
	public String role_id;
	public String role_name;
}
