package entity;

import java.util.Date;

public class order {
	public String order_id;
	public Date order_date;
	public double order_price;
	public String person_id;
}
