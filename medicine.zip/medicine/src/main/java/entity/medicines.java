package entity;

public class medicines {
	public String medicine_id;
	public String medicineName;
	public double price;
	public int store;
	public int category_id;
}
