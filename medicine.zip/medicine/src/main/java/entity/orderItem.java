package entity;

public class orderItem {
	public String order_item_id;
	public int number;
	public double order_item_price;
	public String order_id;
	public String medicine_id;
}
